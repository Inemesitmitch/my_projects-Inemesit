Assignment: Fashion MNIST Classification using CNN in Python & R
Developer: Inemesit Mitchel
Date:04/23/2025


PROJECT OVERVIEW
This project implements a Convolutional Neural Network (CNN) using Keras in both Python and R to classify images from the Fashion MNIST dataset.

FILES INCLUDED:
- Fashion_MNIST.ipynb - jupyter file or testing the models
- Fashion_MNIST.r - r file for testing the models
- README.txt -> Provides instructions for using this script.


REQUIREMENTS
Ensure you have installed the following dependencies:
Python
  - tensorflow
  - kerasw
  - numpy
  - matplotlib

R
  - keras
  - tensorflow
  - ggplot2 (for visualization)
  - install.packages("reshape2")

VISUALIZATION 
- Python: Uses matplotlib.pyplot.
- R: Uses library(reshape2).


EXECUTION STEPS
Python
1. Run the 'Fashion_MNIST.ipynb' script to train and test the model.

R
Run the script in an R environment using:
1. Execute the 'Fashion_MNIST.r' script to train and test the model.

MODEL DESCRIPTION
Both implementations follow a six-layer CNN architecture:
1. Conv2D (32 filters, 3x3 kernel, ReLU activation)
2. MaxPooling2D (2x2 pool size)
3. Conv2D (64 filters, 3x3 kernel, ReLU activation)
4. MaxPooling2D (2x2 pool size)
5. Conv2D (128 filters, 3x3 kernel, ReLU activation)
6. Dense layers (128 neurons, ReLU; 10 neurons, Softmax)

Making Predictions
Both models predict labels for two images from the Fashion MNIST dataset. The predicted class index will be displayed in the output.
