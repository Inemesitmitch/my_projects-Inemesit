Netflix Data Visualization
Module 4 Assignment

Developer: Inemesit Mitchel
Date:04/21/2025 

Contents of the ZIP Folder
1. Netflix_Data_Visualization.ipynb   → Python script
2. Netflix_data_visualization.r    → R script
3. README.txt        → This readme file

Netflix Data Analysis Project
This project involves analyzing Netflix movies and shows using Python and R, focusing on data cleaning, exploration, visualization, and insights generation using Charts.

Project Overview
This project aims to:
- Clean and preprocess Netflix data.
- Explore data to understand missing values and distributions.
- Create visualizations for most watched genres and ratings distribution.
- Use Python libraries (Pandas, Seaborn, Matplotlib) and R (ggplot2).
- Integrate an R-based visualization.


Dataset
The dataset (`Netflix_shows_movies.csv`) contains information about Netflix content, including:
 - show_id      
 - type
 - title        
 - director     
 - cast          
 - country       
 - date_added   
 - release_year  
 - rating        
 - duration      
 - listed_in  
 - description

Requirements
Python Libraries
 - pandas
 - seaborn
 - matplotlib
 - zipfile
 - os

R Libraries
 - ggplot2
 - dplyr

Usage Instructions

 - Python Version-
How to Run the Code
1. Open the folder with the dataset in your python environment.
2. Run the Jupyter Notebook to display insights
This displays the most watched genre and the Rating distribution.

 --- R Version ---
Requirements: R (or RStudio)
Steps:
1. Open R or RStudio.
2. Open the script folder Neflix_data_visualization in the r environment.
3. Run the R script using the df_cleaned cleaned dataset generated from python.
This displays the most watched genre.




