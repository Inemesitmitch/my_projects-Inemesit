library(ggplot2)
setwd("C:\\Users\\Sparkhiee\\Desktop\\assignment python")  # Replace with your actual file path

# Load dataset
df <- read.csv("df_cleaned.csv", header=TRUE, stringsAsFactors=FALSE)

genre_counts <- table(df$listed_in)
# Check missing values
colSums(is.na(df))
# Remove rows with missing values
df_cleaned <- na.omit(df)


# Count the top 10 genres
genre_counts <- table(df$listed_in)
top_10_genres <- head(sort(genre_counts, decreasing=TRUE), 10)
print(top_10_genres)


# Convert to dataframe for visualization
genre_df <- data.frame(Genre=names(top_10_genres), Count=as.numeric(top_10_genres))

# Plot using ggplot2
ggplot(genre_df, aes(x=reorder(Genre, -Count), y=Count)) +
  geom_bar(stat="identity", fill="blue") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  ggtitle("Top 10 Most Watched Genres on Netflix") +
  xlab("Genre") +
  ylab("Count")

# Load dataset
df <- read.csv("df_cleaned.csv")

# Genre distribution visualization
#ggplot(df, aes(x=listed_in)) + 
# geom_bar(fill="blue") + 
#theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
#ggtitle("Most Watched Genres on Netflix")
