class Policyholder:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.active = False
        self.products = []
        self.payments = []

    def register(self):
        self.active = True
        print(f"{self.name} has been registered.")

    def suspend(self):
        self.active = False
        print(f"{self.name}'s account has been suspended.")

    def activate(self):
        self.active = True
        print(f"{self.name}'s account has been reactivated.")

    def add_product(self, product):
        self.products.append(product)
        print(f"{product.name} has been added to {self.name}'s account.")

    def add_payment(self, payment):
        self.payments.append(payment)

    def display_account(self):
        print(f"\nPolicyholder: {self.name}")
        print(f"Email: {self.email}")
        print(f"Status: {'Active' if self.active else 'Suspended'}")
        print("Products:")
        for product in self.products:
            print(f"- {product.name}")
        print("Payments:")
        for payment in self.payments:
            print(f"- Amount: ${payment['amount']} | Status: {payment['status']}")
