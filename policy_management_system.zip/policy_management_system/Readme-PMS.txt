Policy Management System - Milestone Assignment 1
Developer: Inemesit Mitchel
Date:04/14/2025 

Description
This is a Python-based - Policy Management System-for an insurance company. It allows management of policyholders, insurance products, and payment operations, supporting tasks such as:

- Registering, suspending, and reactivating policyholders
- Creating, updating, and suspending products
- Processing payments, applying penalties, and sending reminders
- Displaying full account details of each policyholder

---
Project Structure

policy_management_system
├── main.ipynb - Demonstrates usage of the system 
├── policyholder.py - Contains Policyholder class 
├── product.py -  Contains Product class 
├── payment.py - Contains Payment class 
└── Readme.txt - Project overview and instructions


---

--How to Run this code--
1. Install Python
2. Clone or download this project into your local machine.
3. Open a terminal and navigate to the project directory:cd path/to/policy_management_system
4. Run this file

-- python main.ipynb --

The -main.ipynb file- demonstrates the functionality by:
- Creating one insurance product.
- Registering five policyholders.
- Assigning the product to each policyholder.
- Processing payments for each one.
- Displaying their account details (products + payment history).