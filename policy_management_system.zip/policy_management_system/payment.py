# payment.py
class Payment:
    def __init__(self, amount, status="Paid"):
        self.amount = amount
        self.status = status

    def process_payment(self, policyholder):
        policyholder.add_payment({
            "amount": self.amount,
            "status": self.status
        })
        print(f"{policyholder.name} made a payment of ${self.amount}.")

    @staticmethod
    def send_payment_reminder(policyholder):
        print(f"Reminder sent to {policyholder.email} for payment.")

    @staticmethod
    def apply_penalty(policyholder, amount):
        penalty = {
            "amount": amount,
            "status": "Penalty"
        }
        policyholder.add_payment(penalty)
        print(f"A penalty of ${amount} has been applied to {policyholder.name}.")
