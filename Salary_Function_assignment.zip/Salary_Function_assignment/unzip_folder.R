# Load necessary library
library(utils)

# Step 1: Unzip the Employee Profile folder
unzip("Employee_Profile.zip", exdir = "Employee_Profile")

# Step 2: Load the CSV file
# Replace 'your_employee_name_profile.csv' with the actual CSV filename
csv_filename <- "Employee_Profile/John_MARTIN_profile.csv"
employee_data <- read.csv(csv_filename)

# Step 3: Display the data
print(employee_data)

